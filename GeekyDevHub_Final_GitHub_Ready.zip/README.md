# GeekyDevHub

**GeekyDevHub** ist ein zentrales, modernes App-Portal für Entwickler, die ihre Tools, Prototypen und KI-Projekte professionell präsentieren möchten.

## Features

- 🌐 Projektübersicht mit Klick-Start
- 🔍 Suche und Filter
- 🌓 Dark Mode ready
- 📁 Modular erweiterbar

## Starten (lokal)

```bash
npm install
npm run dev
```

## Deployment

- Vercel-kompatibel (`vite`, `dist` als Output)
- Replit / Netlify geeignet
