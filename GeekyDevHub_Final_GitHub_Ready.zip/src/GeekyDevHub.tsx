import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";

const projects = [
  {
    name: "App!Solut (Update Mai 2025)",
    description: "Altersverifizierung, i18n, neue Kategorien – vollständig integriert.",
    path: "/apps/appsolut/index.html",
  },
  {
    name: "CamCollector",
    description: "Verwalte Kameras und Objektive, erweiterbar mit KI-Features.",
    path: "/apps/camcollector/index.html",
  },
  {
    name: "App!Solut (Variante 1)",
    description: "Alternative Version mit identischem Setup wie Haupt-App.",
    path: "/apps/appsolut-v1/index.html",
  },
  {
    name: "App!Solut (Variante 2)",
    description: "Zweite alternative Variante, vollständig Vite-basiert.",
    path: "/apps/appsolut-v2/index.html",
  }
];

export default function GeekyDevHub() {
  const [filter, setFilter] = useState("");

  const filtered = projects.filter((p) =>
    p.name.toLowerCase().includes(filter.toLowerCase()) ||
    p.description.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-3xl font-bold">GeekyDevHub</h1>
      <input
        className="w-full p-2 border rounded bg-background text-foreground"
        placeholder="🔍 Suche nach Projekt oder Beschreibung..."
        value={filter}
        onChange={(e) => setFilter(e.target.value)}
      />
      <div className="grid md:grid-cols-2 gap-4">
        {filtered.map((project) => (
          <Card key={project.name}>
            <CardContent className="p-4 space-y-2">
              <h2 className="text-xl font-semibold">{project.name}</h2>
              <p className="text-sm text-muted-foreground">{project.description}</p>
              <a href={project.path} target="_blank">
                <Button>🌐 App starten</Button>
              </a>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
